﻿using System;
using System.Data;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;

namespace Shree
{
    public partial class BlogInfo : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
             //Put user code to initialize the page here
            if (IsPostBack)
            {

            }
            else
            {
                // initialize Blog and read it into a dataset
                DataSet dsBlogs = ReadBlogIntoTable();

                // if we created a new entry, append it to the BlogList
                // and save it to the xml file
          //      if ((bool)Session["Changed"])
          //      {
          //          AppendComments(ds);
         //           WriteXmlComments(ds);
         //           Session["Changed"] = false;
         //   }

                // Dynamically build the blog into a WebControls.Table
          //      RebuildTableView(dsBlogs);
            }


        }
        DataSet ReadBlogIntoTable()
        {
            return ReadXmlComments();
        }

        private DataSet ReadXmlComments()
        {
            // construct the DataSet
            DataSet dsBlogs = new DataSet();

            // form the server path of the feedback database
            string filename = Server.MapPath(@".\\App_Data\") + "xmlBlog_Comment.xml";

            // if the file exists, read  the blog database into the data set
            if (File.Exists(filename))
            {
                dsBlogs.ReadXml(filename);
            }
            else
            {
                // otherwise we need to create a new new in-memory 
                // Database table from scratch
                DataTable theTable = new DataTable("xmlBlog_Comment");
                dsBlogs.Tables.Add(theTable);

                // add a name, time, title, and blog columns to our mock-up blog database
                theTable.Columns.Add("Name", Type.GetType("System.String"));
                theTable.Columns.Add("Time", Type.GetType("System.DateTime"));
                theTable.Columns.Add("Title", Type.GetType("System.String"));
                theTable.Columns.Add("Blog", Type.GetType("System.String"));
            }

            return dsBlogs;
        }

        //public DataSet ReadXmlComments()
        //{
        //    DataSet ds = new DataSet();
        //    string sSQL = "SELECT BlogEntryId, BlogEtryComment FROM tbl_BlogEntryComments ORDER BY BlogEntryDate";
        //    SqlDataAdapter sda = new SqlDataAdapter(sSQL, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());
        //    sda.Fill(ds);
        //    return ds;
        //}
        private void WriteXmlComments(DataSet dsBlogs)
        {
            string filename = Server.MapPath(@".\\App_Data\") + "xmlBlogComment.xml";
            dsBlogs.WriteXml(filename);

            //DataSet ds = new DataSet();
            //string sSQL = "SELECT BlogEntryId, BlogEtryComment FROM tbl_BlogEntryComments ORDER BY BlogEntryDate";
            //SqlDataAdapter sda = new SqlDataAdapter(sSQL, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());
            //sda.Fill(ds);
            //return ds;
        }

        /// <summary>
        ///  Append comments to xml file
        /// </summary>
        /// <param name="ds"></param>
        void AppendComments(DataSet dsBlogs)
        {
            //create a new DataRow
            DataRow dr = dsBlogs.Tables["xmlBlog_Comment"].NewRow();
           // DataRow dr = ds.Tables["tbl_BlogEntryComments"].NewRow();
            // Populate the row from the text boxes filled by the user
            dr[0] = Session["Name"];
            dr[1] = DateTime.Now;
            dr[2] = Session["Title"];
            dr[3] = Session["Blog"];

            // add the row to the DataSet
            dsBlogs.Tables["xmlBlog_Comment"].Rows.InsertAt(dr, 0);

            WriteXmlComments(dsBlogs);
        }

        //void RebuildTableView(DataSet dsBlogs)
        //{
        //    string previousUser = "";  // track previous

        //    // loop through each row in the data set and create
        //    // the row on the web page in a web table
        //    foreach (DataRow dr in dsBlogs.Tables[0].Rows)
        //    {
        //        // add title (use a single column)

        //        TableRow tr = new TableRow();
        //        tr.Cells.Add(new TableCell());

        //        // change title color slightly
        //        tr.Cells[0].ForeColor = Color.Navy;
        //        tr.Cells[0].Width = 400;

        //        //  make the text title big and purple
        //        tr.Cells[0].Text = "<FONT SIZE=5 COLOR=purple FACE=Rockwell><B>" + dr[2].ToString() + "</B></FONT>";
        //        BlogTable.Rows.Add(tr); 
        //        this.BlogTable.Rows.Add(tr);

        //        // add blog in a single column and span 2 columns
        //        tr = new TableRow();
        //        tr.Cells.Add(new TableCell());
        //        tr.Cells[0].Width = 550;
        //        tr.Cells[0].ColumnSpan = 2;
        //        tr.Cells[0].Text = dr[3].ToString();
        //        BlogTable.Rows.Add(tr); 
        //        this.BlogTable.Rows.Add(tr);

        //        // add user who posted and date (use two columns in the row)
        //        tr = new TableRow();
        //        tr.Height = 50;
        //        tr.HorizontalAlign = HorizontalAlign.Left;
        //        tr.VerticalAlign = VerticalAlign.Bottom;
        //        tr.Cells.Add(new TableCell());
        //        tr.Cells.Add(new TableCell());


        //        tr.Cells[0].Text = "Posted by " + dr[0].ToString();
        //        DateTime postTime = DateTime.Parse(dr[1].ToString());
        //        tr.Cells[1].HorizontalAlign = HorizontalAlign.Left;

        //        tr.Cells[1].Text = String.Format("<i>{0}</i>", postTime.ToString("MMM dd, 2014 @ hh:mm"));
        //        BlogTable.Rows.Add(tr); 
        //        this.BlogTable.Rows.Add(tr);

        //        // add separtor graphic and span 2 columns
        //        tr = new TableRow();
        //        tr.Cells.Add(new TableCell());
        //        tr.Cells.Add(new TableCell());
        //        tr.Cells[0].ColumnSpan = 2;
        //        BlogTable.Rows.Add(tr); 
        //        this.BlogTable.Rows.Add(tr);

        //        string imageFile = this.ResolveUrl(@".\images\separator.jpg");
        //        System.Web.UI.WebControls.Image separator = new System.Web.UI.WebControls.Image();
        //        separator.ImageUrl = imageFile;
        //        separator.Width = 600;
        //        separator.Height = 32;
        //        separator.Visible = true;

        //        tr.Cells[0].Controls.Add(separator);
        //        tr.Cells[0].HorizontalAlign = HorizontalAlign.Center;
        //    }

        //}
        protected void btnOpenEntry_Click(object sender, System.EventArgs e)
        {
           // Response.Redirect("BlogEntry.aspx");
        }
    }
}