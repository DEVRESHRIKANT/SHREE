﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
//using System.ServiceModel;
using System.Runtime.Serialization;
//using System.ServiceProcess;
using System.Web.UI.WebControls;
using System.Text;

namespace Shree
{
    public partial class CloudComputing : System.Web.UI.Page
    {
        //protected void Page_Load(object sender, EventArgs e)
        //{
            
        //}
    }
}