﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Shree.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult BuildServer()
        {
            return View();
        }

        public ActionResult BusinessAnalyst()
        {
            return View();
        }
        public ActionResult EngagementModels()
        {
            return View();
        }

        public ActionResult ContinuousIntegration()
        {
            return View();
        }

        public ActionResult CSharp()
        {
            return View();
        }

        public ActionResult DataWarehouse()
        {
            return View();
        }

        public ActionResult CloudComputing()
        {
            return View();
        }

        public ActionResult InfrastructureMgmt()
        {
            return View();
        }

        public ActionResult SharePoint()
        {
            return View();
        }

        public ActionResult ExchangeServer()
        {
            return View();
        }

        public ActionResult QualityAssurance()
        {
            return View();
        }
        public ActionResult QA_Templates()
        {
            return View();
        }

        public ActionResult AutomationFrame()
        {
            return View();
        }
        public ActionResult ProjectCharter()
        {
            return View();
        }
        public ActionResult PM_Templates()
        {
            return View();
        }
        public ActionResult RiskMgmt()
        {
            return View();
        }

        
        public ActionResult Clients()
        {
            return View();
        }
        public ActionResult Consultants()
        {
            return View();
        }

    }
}
