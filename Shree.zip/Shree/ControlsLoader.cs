using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

    /// <summary>
    /// Summary description for ControlsLoader.
    /// </summary>
    public class ControlsLoader
    {
        public const string ConnStr = "Initial Catalog=ShriVV;Data Source=dbShriVV;Integrated Security=SSPI;";
        public ControlsLoader()
        { }

        //public DataSet GetCountry()
        //{

        //    DataSet dsCountry = fetchData.ExecuteDataset(System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString(),
        //        CommandType.Text,
        //        "SELECT CountryName, CountryCd FROM tblCountry", null);

        //    return dsCountry;

        //    DataSet ds = new DataSet();
        //    string sSQL = "SELECT CountryName, CountryCd FROM tblCountry";

        //    SqlDataAdapter sda = new SqlDataAdapter(sSQL, ControlsLoader.ConnStr);
        //    //SqlDataAdapter sda1 = new SqlDataAdapter(sSQL1, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());

        //    sda.Fill(ds);
        //    //sda1.Fill(ds);

        //    return ds;
        //}

        public DataSet GetUserName(int pUserId)
        {
            string shriUserName;
            DataSet dsUserName = new DataSet();
            string SQLUserName = "SELECT UserId, UserName FROM tblUsers WHERE UserId = " + pUserId + " ORDER BY UserName";
            SqlDataAdapter sdaUserName = new SqlDataAdapter(SQLUserName, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());
            sdaUserName.Fill(dsUserName);
            shriUserName = sdaUserName.GetFillParameters("UserName");
            return dsUserName;
        }

        //public DataSet GetUserId(string pUserName)
        //{
        //    int shriUserId;
        //    DataSet dsUserId = new DataSet();
        //    string SQLUserId = "SELECT UserId, UserName FROM tblUsers WHERE UserName = " + pUserName + " ORDER BY UserName";
        //    SqlDataAdapter sdaUserId = new SqlDataAdapter(SQLUserId, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());
        //    sdaUserId.Fill(dsUserId);
        //    shriUserId = sdaUserId.GetFillParameters("UserId");
        //    return dsUserId;
        //}

        public DataSet GetRoleId()
        {
            DataSet datasetRole = new DataSet();
            string SQLRole = "SELECT RoleId, RoleName FROM tblRoles ORDER BY RoleName";
            SqlDataAdapter sdaRole = new SqlDataAdapter(SQLRole, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());
            sdaRole.Fill(datasetRole);
            return datasetRole;
        }

        public DataSet GetOwnership()
        {
            DataSet ds = new DataSet();
            string sSQL = "SELECT OwnershipName, OwnershipCd FROM tblOwnerships ORDER BY OwnershipName";
            SqlDataAdapter sda = new SqlDataAdapter(sSQL, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());

            sda.Fill(ds);

            return ds;
        }

        public DataSet GetClients()
        {
            DataSet ds = new DataSet();
            string sSQL = "SELECT ClientName, ClientId FROM tblClients ORDER BY ClientName";
            SqlDataAdapter sda = new SqlDataAdapter(sSQL, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());

            sda.Fill(ds);

            return ds;
        }

        public DataSet GetUsers()
        {
            DataSet ds = new DataSet();
            string sSQL = "SELECT UserName, UserId FROM tblUsers ORDER BY UserName";
            SqlDataAdapter sda = new SqlDataAdapter(sSQL, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());

            sda.Fill(ds);

            return ds;
        }

        public DataSet GetClientRole(int pRoleId)
        {
            DataSet ds = new DataSet();
            string sSQL = "SELECT ClientName, ClientId FROM tblClients WHERE RoleId = " + pRoleId + " ORDER BY ClientName";
            SqlDataAdapter sda = new SqlDataAdapter(sSQL, ConfigurationSettings.AppSettings["ConnString"].ToString());
            sda.Fill(ds);
            return ds;
        }

        public DataSet GetStates(int pCountryCd)
        {
            DataSet ds = new DataSet();
            string sSQL = "SELECT StateName, StateCd FROM tblStates WHERE CountryCd = " + pCountryCd + " ORDER BY StateName";
            SqlDataAdapter sda = new SqlDataAdapter(sSQL, System.Configuration.ConfigurationManager.AppSettings["ConnString"].ToString());

            sda.Fill(ds);

            return ds;
        }

    }

