USE [Shree_Database]
GO
/****** Object:  StoredProcedure [dbo].[InsertRole]    Script Date: 2/27/2015 5:44:21 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[InsertRole]
		   (@rolename varchar(50)
           )
AS
BEGIN
INSERT INTO [dbo].[tbl_UserRole]
           ([RoleName] 
           )
     VALUES
           (@rolename           
           )
END
