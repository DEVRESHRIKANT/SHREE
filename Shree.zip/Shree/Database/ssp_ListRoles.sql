USE [Shree_Database]
GO
/****** Object:  StoredProcedure [dbo].[ssp_DeleteRole]    Script Date: 2/27/2015 5:46:30 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[ssp_ListRoles]

    -- Add the parameters for the stored procedure here

    @RoleName nvarchar(MAX)

AS

BEGIN

    SET NOCOUNT ON; 

    SELECT * 
	FROM tbl_UserRole
	WHERE Status = 1
END

