USE [Shree_Database]
GO
/****** Object:  Table [dbo].[tblClients]    Script Date: 06/30/2008 16:29:21 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[tbl_Clients](
	[ClientId] [int] NOT NULL,	
	[ClientName] [varchar](35) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[Address1] [varchar](40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Address2] [varchar](40) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[City] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[SubLocation] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PhoneCountryCd] [varchar](4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PhoneCityCd] [varchar](4) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PhoneNumber] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[Status] [bit] NULL,
	[RoleId] [bigint] NULL,
	[Profile] [varchar](50) NULL,
	[ProjectId] [bigint] NULL,
	[ConsultantId] [bigint] NULL,
	[Domain] [varchar](50) NULL,
	[EmailAddress] [varchar](80) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[WebsiteURL] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,		
	[IDIssueDate] [datetime] NULL,
	[RegisterDate] [datetime] NULL,
	[LeavingDate] [datetime] NULL,	
)
GO
SET ANSI_PADDING OFF