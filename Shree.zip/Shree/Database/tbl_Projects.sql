USE [Shree_Database]
GO

/****** Object:  Table [dbo].[tbl_Projects]    Script Date: 2020-04-20 9:55:46 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_Projects](
	[ProjectId] [bigint] IDENTITY(1,1) NOT NULL,
	[ClientId] [bigint] NULL,
	[ConsultantId] [bigint] NULL,
	[UserId] [bigint] NULL,
	[Project_Start_Dt] [datetime] NULL,
	[Project_End_Dt] [datetime] NULL,
	[ProjectName] [varchar](50) NOT NULL,
	[Duration] [varchar](50) NULL,
	[Domain] [varchar](50) NULL,
	[Technology] [varchar](50) NULL,
	[Status] [bit] NULL,
	[Details] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[ProjectId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


