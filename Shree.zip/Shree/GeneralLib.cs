using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using ShriVV;

namespace ShriVV
{
	/// <summary>
	/// Summary description for GeneralLib.
	/// </summary>
	public class GeneralLib
	{
		public const string ConnStr = "Initial Catalog=ShriVV;Data Source=dbShriVV;Integrated Security=SSPI;";
		public string shriUserName;
        
        public GeneralLib()
        {}
        
    }
}