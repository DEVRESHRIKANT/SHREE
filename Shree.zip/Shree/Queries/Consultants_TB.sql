USE [infosys247]
GO

/****** Object:  Table [dbo].[Consultants_TB]    Script Date: 10/4/2014 8:56:49 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Consultants_TB](
	[ConsultantId] [bigint] IDENTITY(1,1) NOT NULL,
	[ConsultantName] [varchar](35) NOT NULL,
	[Address1] [varchar](40) NULL,
	[Address2] [varchar](40) NULL,
	[City] [varchar](30) NULL,
	[PhoneNumber] [varchar](20) NULL,
	[EmailAddress] [varchar](80) NULL,
	[WebsiteURL] [varchar](50) NULL,
	[RegisterDate] [datetime] NULL,
	[ModifiedDate] [datetime] NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[Status] [bit] NULL,
	[RoleId] [bigint] NULL,
	[Profile] [varchar](50) NULL,
	[ProjectId] [bigint] NULL,
	[Domain] [varchar](50) NULL,
	[Location] [varchar](50) NULL,
	[Technology] [varchar](50) NULL,
	[Photo] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[ConsultantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


