USE [Infosys247]
GO

/****** Object:  Table [dbo].[ProjectUser_TB]    Script Date: 2/27/2015 5:20:58 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ProjectUser_TB](
	[UserId] [bigint] NOT NULL,
	[ProjectId] [bigint] NOT NULL,
	[Status] [bit] NOT NULL,
	[ModifiedDate] [datetime] NULL,
	[ProjectUserId] [bigint] NOT NULL,
	PRIMARY KEY CLUSTERED 
(
	[ProjectUserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET ANSI_PADDING OFF
GO


