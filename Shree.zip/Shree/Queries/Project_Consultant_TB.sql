USE [infosys247]
GO

/****** Object:  Table [dbo].[Project_Consultant_TB]    Script Date: 10/4/2014 8:57:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Project_Consultant_TB](
	[ConsultantId] [bigint] NOT NULL,
	[ProjectId] [bigint] NOT NULL
) ON [PRIMARY]

GO


