USE [infosys247]
GO

/****** Object:  Table [dbo].[Projects_TB]    Script Date: 10/4/2014 8:58:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Projects_TB](
	[ProjectId] [bigint] IDENTITY(1,1) NOT NULL,
	[ClientId] [bigint] NULL,
	[ConsultantId] [bigint] NULL,
	[ProjectName] [varchar](50) NOT NULL,
	[Duration] [varchar](50) NULL,
	[Domain] [varchar](50) NULL,
	[Technology] [varchar](50) NULL,
	[Details] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[ProjectId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


