    
CREATE PROCEDURE SP_INSERT_SUBMITTED_FORMS
		(@pForm_ID int,
		 @pUSER_ID varchar(50),
	     @pTemplate_ID int,
	     @pExec_ID varchar(100),
	     @pCreated_User varchar(100),
	     @pCurrentDate NVARCHAR(32),		           
	     @pForm_Process_Status varchar(100))
AS

SET NOCOUNT ON;
SET XACT_ABORT OFF -- Allow procedure to continue after error

DECLARE	
	@NestedProc     BIT = 1 
	   
BEGIN TRY
	IF @@TRANCOUNT = 0
        BEGIN
            SET @NestedProc = 0
            BEGIN TRANSACTION Insert_Submitted
        END
	--BEGIN TRANSACTION 
    INSERT INTO SF_Submitted_Forms_TB
           (Form_ID,
            User_ID,            
            Exec_ID, 
            Create_User, 
            Create_TS, 
            Form_Process_Status)
	 VALUES
	       (@pForm_ID,
	        @pUSER_ID,	        
	        @pExec_ID,
	        @pCreated_User,
	        @pCurrentDate,
	        @pForm_Process_Status) 
	  
        --Commit the transaction 
        IF @@TRANCOUNT > 0 AND @NestedProc = 0
        BEGIN
            COMMIT TRANSACTION Insert_Submitted
        END
	              
END TRY

BEGIN CATCH
        --Roll back the transaction
        IF @@TRANCOUNT > 0 AND @NestedProc = 0
        BEGIN
            ROLLBACK TRANSACTION Insert_Submitted
        END       
                
        IF( XACT_STATE()) <>0
        BEGIN
            ROLLBACK TRANSACTION Insert_Submitted
        END
	   
END CATCH
COMMIT



