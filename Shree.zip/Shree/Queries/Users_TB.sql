USE [infosys247]
GO

/****** Object:  Table [dbo].[tbl_Users]    Script Date: 10/4/2014 8:59:37 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[tbl_Users](
	[UserId] [bigint] IDENTITY(1,1) NOT NULL,
	[UserPassword] [varchar](50) NULL,
	[UserName] [varchar](35) NOT NULL,
	[Location] [varchar](30) NULL,
	[PhoneNumber] [varchar](20) NULL,
	[EmailAddress] [varchar](80) NULL,
	[WebsiteURL] [varchar](50) NULL,
	[RegisterDate] [datetime] NULL,
	[ModifiedDate] [datetime] NULL,
	[ProfileName] [varchar](30) NULL,
	[ImageName] [varchar](30) NULL,
	[RoleName] [varchar](20) NULL,
	[FirstName] [varchar](50) NULL,
	[LastName] [varchar](50) NULL,
	[LoginId] [varchar](50) NULL,
	[Status] [bit] NULL,
 CONSTRAINT [PK_tbl_Users] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


