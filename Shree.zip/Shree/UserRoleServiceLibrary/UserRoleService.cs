﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Windows;
using System.Net;


namespace UserRoleServiceLibrary
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class UserRoleService : IUserRoleService
    {
        public Employee[] GetEmployees()
        {
            return new Employee[] 
             {
                  new Employee() {EmpNo=101,EmpName="Mahesh",DeptName="CTD"},
                  new Employee() {EmpNo=102,EmpName="Akash",DeptName="HRD"}
             };
        }
    }
}
